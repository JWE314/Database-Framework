
/*Sort mytable*/

function sortTable(n) {
	var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
	table = document.getElementById("mytable");
	switching = true;
	dir = "asc";
	while (switching) {
		switching = false;
		rows = table.rows;
		for (i = 1; i < (rows.length - 1); i++) {
			shouldSwitch = false;
			x = rows[i].getElementsByTagName("a")[n];
			y = rows[i + 1].getElementsByTagName("a")[n];
			if (dir == "asc") {
				if (x.innerHTML.toUpperCase() > y.innerHTML.toUpperCase()) {
					shouldSwitch = true;
					break;
				}
			} else if (dir == "desc") {
				if (x.innerHTML.toUpperCase() < y.innerHTML.toUpperCase()) {
					shouldSwitch = true;
					break;
				}
			}
		}
		if (shouldSwitch) {
			rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
			switching = true;
			switchcount ++; 
		} else {
			if (switchcount == 0 && dir == "asc") {
				dir = "desc";
				switching = true;
			}
		}
	}
}

/*Table Filter*/

function Filter(n) {
    var input, filter, table, tr, td, i, txtValue, count;
    input = document.getElementById("searchbox" + n);
    filter = input.value.toUpperCase();
    table = document.getElementById("mytable");
    tr = table.getElementsByTagName("tr");
    for (i = 0, count = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[n];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
                if (count++ % 2 == 0) {
                  tr[i].style.background = "#F6F6F6";
                } else {
                  tr[i].style.background = "#EEEEEE";
                }
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}